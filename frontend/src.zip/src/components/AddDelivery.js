import React, { useState } from "react";
import axios from "axios";
import "./details.css"
import "./header.css"
import {useNavigate} from 'react-router-dom';


function AddDelivery(){

    const navigate = useNavigate();  

    const [date, setDate] = useState("");
    const [orderNo, setOrderNo] = useState("");
    const [vehicleNo, setVehicleNo] = useState("");
    const [status, setStatus] = useState("");


    function sendData(e){
        e.preventDefault();

        const newDelivery = {
            date,
            orderNo,
            vehicleNo,
            status,
        }


        axios.post("http://localhost:8070/delivery/add", newDelivery).then(()=>{
            alert("Delivery successfully added");
            navigate("/getDelivery")

        }).catch((err)=>{
            alert(err);
        })

    }
   

    return (
        
            <div class="home-section">
                <h2 className="form_head">Enter Delivery Details</h2>
                <form class="vehicleform" onSubmit={sendData}>
                <div class="mb-3">
                    <label class="form-label">Date</label>
                    <input type="date" className="vehicleInput"
                    onChange={(e)=>{
                        setDate(e.target.value);
                    }} />
                </div>

                <div class="mb-3">
                    <label  class="form-label">Order Number</label>
                    <input type="text" className="vehicleInput"
                    onChange={(e)=>{
                        setOrderNo(e.target.value);
                    }} />
                </div>

                <div class="mb-3">
                    <label class="form-label">Vehicle Number</label>
                    <input type="text" className="vehicleInput"
                    onChange={(e)=>{
                        setVehicleNo(e.target.value);
                    }} />
                </div>              

                <div class="mb-3">
                    <label  class="form-label">Status</label>

                    <select  onChange={(e)=>{
                        setStatus(e.target.value);
                    }}>
                        <option value="Delivered" selected>Delivered</option>
                        <option value="In Delivery">In Delivery</option>
                    </select>

    
                </div>

        

                <button type="submit" className="updateBtn">Submit</button>
                </form>
            </div>
       
    )
} 

 export default AddDelivery;
