import React, { useState } from "react";
import axios from "axios";
import "./details.css"
import "./header.css"
import {useNavigate,useLocation} from 'react-router-dom';


function UpdateDelivery (){

    const { state } = useLocation();
    const navigate = useNavigate();  

    const [date, setDate] = useState(`${state.date}`);
    const [orderNo, setOrderNo] = useState(`${state.orderNo}`);
    const [vehicleNo, setVehicleNo] = useState(`${state.vehicleNo}`);
    const [status, setStatus] = useState(`${state.status}`);

    function sendData(e){
        e.preventDefault();

        const newDelivery = {
            date,
            orderNo,
            vehicleNo,
            status,
        }


        axios.put(`http://localhost:8070/delivery/update/${state.id}`, newDelivery ).then(()=>{
            alert("Delivery details updated");
            navigate("/getDelivery")

        }).catch((err)=>{
            alert(err);
        })

    }
   

    return (
        
            <div class="home-section">
                <h2 className="form_head">Update Delivery Details</h2>
                <form class="vehicleform" onSubmit={sendData}>
                <div class="mb-3">
                    <label class="form-label">Delivery Date</label>
                    <input type="date" className="vehicleInput" value={date}
                    onChange={(e)=>{
                        setDate(e.target.value);
                    }} />
                </div>

                <div class="mb-3">
                    <label  class="form-label">Order Number</label>
                    <input type="text" className="vehicleInput" value={orderNo}
                    onChange={(e)=>{
                        setOrderNo(e.target.value);
                    }} />
                </div>

                <div class="mb-3">
                    <label class="form-label">Vehicle Number</label>
                    <input type="text" className="vehicleInput" value={vehicleNo}
                    onChange={(e)=>{
                        setVehicleNo(e.target.value);
                    }} />
                </div>
             

                <div class="mb-3">
                    <label  class="form-label">Status</label>
                    <input type="text" className="vehicleInput" value={status}
                    onChange={(e)=>{
                        setStatus(e.target.value);
                    }} />
                </div>

        

                <button type="submit" className="updateBtn">Submit</button>
                </form>
            </div>
       
    )
} 

 export default UpdateDelivery;
