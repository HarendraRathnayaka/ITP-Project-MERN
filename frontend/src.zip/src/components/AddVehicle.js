import React, { useState } from "react";
import axios from "axios";
import "./details.css"
import "./header.css"
import { useNavigate } from 'react-router-dom';

function AddVehicle() {
  const navigate = useNavigate();  

  const [vehicleNo, setVehicleNo] = useState("");
  const [vehicleType, setVehicleType] = useState("");
  const [fuelConsumptionRate, setFuelConsumptionRate] = useState("");
  const [driverID, setDriverID] = useState("");
  const [drivingLicenseNo, setDrivingLicenseNo] = useState("");

  function sendData(e) {
    e.preventDefault();

    const newVehicle = {
      vehicleNo,
      vehicleType,
      fuelConsumptionRate,
      driverID,
      drivingLicenseNo,
    }

    axios.post("http://localhost:8070/vehicle/add", newVehicle)
      .then(() => {
        alert("vehicle added");
        navigate("/getVehicles")
      })
      .catch((err) => {
        alert(err);
      })
  }

  return (
    <div className="home-section">
      <h2 className="form_head">Enter Vehicle Details</h2>
      <form className="vehicleform" onSubmit={sendData}>
        <div className="mb-3">
          <label className="form-label">Vehicle Number</label>
          <input type="text" className="vehicleInput" required minLength="7" maxLength="7"
            pattern="[A-Za-z]{2}[0-9]{5}" title="Enter a valid vehicle number (eg: AB12345)"
            onChange={(e) => {
              setVehicleNo(e.target.value);
            }} />
        </div>

        <div className="mb-3">
          <label className="form-label">Vehicle Type</label>
          <input type="text" className="vehicleInput" required
            onChange={(e) => {
              setVehicleType(e.target.value);
            }} />
        </div>

        <div className="mb-3">
          <label className="form-label">Fuel Consumption Rate (Permissible lowest value)</label>
          <input type="number" className="vehicleInput" required min="0"
            onChange={(e) => {
              setFuelConsumptionRate(e.target.value);
            }} />
        </div>

        <div className="mb-3">
          <label className="form-label">Driver ID</label>
          <input type="text" className="vehicleInput" required
            onChange={(e) => {
              setDriverID(e.target.value);
            }} />
        </div>

        <div className="mb-3">
          <label className="form-label">Driving Licence No</label>
          <input type="text" className="vehicleInput" required minLength="8" maxLength="8"
            pattern="[0-9]{8}" title="Enter a valid driving licence number (eg: 12345678)"
            onChange={(e) => {
              setDrivingLicenseNo(e.target.value);
            }} />
        </div>

        <button type="submit" className="updateBtn">Submit</button>
                </form>
            </div>
       
    )
} 

 export default AddVehicle;
