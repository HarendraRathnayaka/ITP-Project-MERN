import React, {useState, useEffect} from "react";
import {Link, useLocation,useNavigate} from 'react-router-dom';
import axios from "axios";

import "./details.css";



function UpdateVehicle(){

    const { state } = useLocation();

   
        const [vehicleNo, setVehicleNo] = useState(`${state.vehicleNo}`);
        const [vehicleType, setVehicleType] = useState(`${state.vehicleType}`);
        const [fuelConsumptionRate, setFuelConsumptionRate] = useState(`${state.fuelConsumptionRate}`);
        const [driverID, setDriverID] = useState(`${state.driverID}`);
        const [drivingLicenseNo, setDriverLicenseNumber] = useState(`${state.drivingLicenseNo}`);


        function updateData(e){
            e.preventDefault();

            const newVehicle = {
                vehicleNo,
                vehicleType,
                fuelConsumptionRate,
                driverID,
                drivingLicenseNo
            }

            axios.put(`http://localhost:8070/vehicle/update/${state.id}`, newVehicle).then(()=>{
                alert("Vehicle updated");
            }).catch((err)=>{
                alert(err);
            })

        }




        return (
            <div class="home-section">
                <h1 className="form_head">Update Vehicle details</h1>
                <form class="vehicleform" onSubmit={updateData}>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Vehicle Number</label>
                    <input type="text" className="vehicleInput" aria-describedby="emailHelp" value={vehicleNo}
                    onChange={(e)=>{
                        setVehicleNo(e.target.value);
                    }} />
                </div>

                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Vehicle Type</label>
                    <input type="text" className="vehicleInput" value={vehicleType}
                    onChange={(e)=>{
                        setVehicleType(e.target.value);
                    }} />
                </div>

                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Fuel Consumption Rate (Permissible lowest value)</label>
                    <input type="text" className="vehicleInput" value={fuelConsumptionRate}
                    onChange={(e)=>{
                        setFuelConsumptionRate(e.target.value);
                    }} />
                </div>

                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Driver ID</label>
                    <input type="text" className="vehicleInput" value={driverID}
                    onChange={(e)=>{
                        setDriverID(e.target.value);
                    }}/>
                </div>

                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Driver's License Number</label>
                    <input type="text" className="vehicleInput" value={drivingLicenseNo}
                    onChange={(e)=>{
                        setDriverLicenseNumber(e.target.value);
                    }}/>
                </div>               
              

                <button type="submit" className="updateBtn">Update</button>
                </form>
            </div>
        )

}

export default UpdateVehicle;