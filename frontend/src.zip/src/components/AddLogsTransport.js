import React, { useState } from "react";
import axios from "axios";
import "./details.css"
import "./header.css"
import {useNavigate} from 'react-router-dom';


function AddLogsTransport (){

    const navigate = useNavigate();  

    const [date, setDate] = useState("");
    const [vehicleNo, setVehicleNo] = useState("");
    const [purchaseOrderNo, setPurchaseOrderNo] = useState("");
    const [noOfKms, setNoOfKms] = useState("");
    const [fuelConsumption, setFuelConsumption] = useState("");
    const [timberVolume, setTimberVolume] = useState("");

    function sendData(e){
        e.preventDefault();

        const newTransport = {
            date,
            vehicleNo,
            purchaseOrderNo,
            noOfKms,
            fuelConsumption,
            timberVolume,
        }


        axios.post("http://localhost:8070/transportation/add", newTransport ).then(()=>{
            alert("transportation added");
            navigate("/getTransportation")

        }).catch((err)=>{
            alert(err);
        })

    }
   

    return (
        
            <div class="home-section">
                <h2 className="form_head">Enter Transportation Details</h2>
                <form class="vehicleform" onSubmit={sendData}>
                <div class="mb-3">
                    <label class="form-label">Date</label>
                    <input type="date" className="vehicleInput"
                    onChange={(e)=>{
                        setDate(e.target.value);
                    }} />
                </div>

                <div class="mb-3">
                    <label class="form-label">Vehicle Number</label>
                    <input type="text" className="vehicleInput"
                    onChange={(e)=>{
                        setVehicleNo(e.target.value);
                    }} />
                </div>

                <div class="mb-3">
                    <label  class="form-label">Purchase Order Number</label>
                    <input type="text" className="vehicleInput"
                    onChange={(e)=>{
                        setPurchaseOrderNo(e.target.value);
                    }} />
                </div>

                <div class="mb-3">
                    <label  class="form-label">Number of Kilometers</label>
                    <input type="text" className="vehicleInput"
                    onChange={(e)=>{
                        setNoOfKms(e.target.value);
                    }} />
                </div>

                <div class="mb-3">
                    <label class="form-label">Fuel Consumption</label>
                    <input type="text" className="vehicleInput"
                    onChange={(e)=>{
                        setFuelConsumption(e.target.value);
                    }}/>
                </div>

                <div class="mb-3">
                    <label class="form-label">Timber Volume</label>
                    <input type="text" className="vehicleInput"
                    onChange={(e)=>{
                        setTimberVolume(e.target.value);
                    }}/>
                </div>

        

                <button type="submit" className="updateBtn">Submit</button>
                </form>
            </div>
       
    )
} 

 export default AddLogsTransport;
